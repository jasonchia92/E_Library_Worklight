	$('a').click(function(event){
    event.preventDefault(); 
	});