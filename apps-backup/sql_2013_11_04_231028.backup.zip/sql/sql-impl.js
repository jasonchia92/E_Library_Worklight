/*
 *  Licensed Materials - Property of IBM
 *  5725-G92 (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
 *  US Government Users Restricted Rights - Use, duplication or
 *  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/************************************************************************
 * Implementation code for procedure - 'procedure1'
 *
 *
 * @return - invocationResult
 */
 
var procedure1inster = WL.Server.createSQLStatement("INSERT INTO buy_book(buy_id,buy_title,buy_author,buy_press,buy_pricing,buy_ISBN,school_number,who_buy,dep,col)"+
"VALUES (?,?,?,?,?,?,?,?,?,?)");

function insertinto(buy_id,buy_title,buy_author,buy_press,buy_pricing,buy_ISBN,school_number,who_buy,dep,col) {
	return WL.Server.invokeSQLStatement({
	preparedStatement : procedure1inster,
	parameters : [buy_id,buy_title,buy_author,buy_press,buy_pricing,buy_ISBN,school_number,who_buy,dep,col]
	});
	}

/************************************************************************
 * Implementation code for procedure - 'procedure2'
 *
 *
 * @return - invocationResult
 */
var procedure2Statement = WL.Server.createSQLStatement("select * from buy_book where buy_id = ?");
function procedure2(buy_id) {
	  return WL.Server.invokeSQLStatement({
	    preparedStatement : procedure2Statement,
	    parameters : [buy_id]
	  });
}



