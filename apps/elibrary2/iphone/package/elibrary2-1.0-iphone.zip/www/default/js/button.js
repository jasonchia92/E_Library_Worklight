
/* JavaScript content from js/button.js in folder common */
	$('a').click(function(event){
    event.preventDefault(); 
	});